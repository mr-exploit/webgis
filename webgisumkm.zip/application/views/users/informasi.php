<div>
    <div class="container text-center">

        <h1 class="mb-5">Informasi UMKM</h1>
        <div class="row mb-5">

            <div class="col-md-5 mx-5">

                <div class="card">

                    <div class="card-body">
                        <h5>DATA KECAMATAN UMKM BATAM</h6>
                            <div id="kecamatan"></div>
                    </div>
                </div>
            </div>
            <div class="col-md-5 ms-5">

                <div class="card">
                    <div class="card-body" id="jenis">
                        <h5>DATA JENIS UMKM BATAM</h6>
                            <div id="jenisusaha"></div>
                    </div>
                </div>
            </div>
        </div>
        <h1>PETA KOTA BATAM</h1>
        <h1>PERSEBARAN UMKM KOTA BATAM</h1>
    </div>
</div>