<div>
    <div class="container text-center">

        <h1 class="mb-5">KONTAK SAYA</h1>
        <div class="row mb-5">

            <div class="col-md-5 mx-5">

                <div class="card">

                    <div class="card-body">
                        <a href="https://wa.me/6282268378605" target="_blank">
                            <i class="bi bi-whatsapp" style="font-size: 15rem; color: green;"></i>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-5 ms-5">

                <div class="card">
                    <div class="card-body">
                        <a href="mailto:gloria@email.com">
                            <i class="bi bi-envelope" style="font-size: 15rem; color: green;"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>