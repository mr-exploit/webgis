<div class="image-container">
  <img src="<?= base_url('assets/'); ?>img/logopoltek.jpg" width="100%" height="682px" />
  <div class="text-overlay">
    <h1 class="text-center">
      SELAMAT DATANG DI WEBGIS PERSEBARAN <br>
      UMKM KOTA BATAM TAHUN 2024
    </h1>
  </div>
</div>